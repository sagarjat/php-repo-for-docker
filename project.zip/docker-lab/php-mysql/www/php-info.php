<?php
   echo 'PHP-MySQL demo application for docker by MyOnlineEdu.com';
   phpinfo();
?>